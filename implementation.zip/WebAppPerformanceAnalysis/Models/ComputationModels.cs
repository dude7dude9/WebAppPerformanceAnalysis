﻿namespace WebAppPerformanceAnalysis.Models
{
    public class ComputationModels
    {
        public int[] rgba0 { get; set; }
        public int[] rgba1 { get; set; }
        public int[] rgba2 { get; set; }
        public int[] rgba3 { get; set; }
        public int[] rgba4 { get; set; }
        public int[] rgba5 { get; set; }
        public int[] rgba6 { get; set; }
        public int[] rgba7 { get; set; }
        public int[] rgba8 { get; set; }
        public int[] rgba9 { get; set; }
    }
}
