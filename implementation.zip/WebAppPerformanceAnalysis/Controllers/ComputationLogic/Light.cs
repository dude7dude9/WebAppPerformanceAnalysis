﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppPerformanceAnalysis.Controllers.ComputationLogic
{
    public class Light
    {
        public Vector position;
        public Color ambient;
        public Color diffuse;
        public Color specular;

        public Light()
        {

        }

    }
}